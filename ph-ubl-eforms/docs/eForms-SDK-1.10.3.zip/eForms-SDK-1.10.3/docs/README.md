# eForms SDK Documentation

Please use the [**TED Developer Docs**](https://docs.ted.europa.eu/) portal if you want to read the eForms SDK Documentation.

The eForms SDK Documentation is written in AsciiDoc, following the **docs-as-code** paradigm. If you want to contribute to the eForms SDK Documentation, you can do so through the [eforms-docs](https://github.com/OP-TED/eforms-docs) Github repository where we maintain our asciidoc sources.