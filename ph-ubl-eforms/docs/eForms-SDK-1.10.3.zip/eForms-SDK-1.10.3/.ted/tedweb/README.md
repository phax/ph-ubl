# Search and reporting metadata

>### ⚠️ **CAUTION**
>**The contents of this folder should not be used by eSenders or other 3rd party applications.** 

This folder contains EFX definitions of eForms terms used by the TED website to index published notices and generate reports. 

This information is specifically designed to cover **temporary needs** of the TED Website during the transition period. Applications of eSenders should not use the information in this folder as it is subject to change or even removal.