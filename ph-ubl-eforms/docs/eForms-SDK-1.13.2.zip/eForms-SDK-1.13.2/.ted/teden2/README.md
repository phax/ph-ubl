# TEDEN2 

This folder contains definitions used by TEDEN2 application.

The information is specifically designed to cover TED eNotices2 features. 
